/***********************************************************************
 * Component:
 *    Assignment 10, Word Count
 *    Brother Kirby, CS235
 * Author:
 *    Daniel Perez, Jamie Hurd, Benjamin Dyas
 * Summary:
 *    Implementation of the map data structure
 ************************************************************************/

#ifndef MAP_H
#define MAP_H

#include "bst.h"
#include "pair.h"

/************************************************
 * MAP
 * An associative container formed with a key
 * value and a data value
 ***********************************************/
template <class K, class V> // key, value pair
class map {
   public:

    // constructors and destructor
    map();
    map (const map<K,V> &rhs);
    ~map() { clear(); };
    
    //overloaded operators
    map & operator = (const map<K,V> &rhs); // assignment
    V &operator[] (const K &k);
    V operator[] (const K &k) const;
    
    // does this get handled inside of pair?
    map operator > (K k) {  }; // greater-than operator for "key"
    map operator = (K k); // assignment operator for key, p. 258
    
    // standard MAP interfaces
    int  size() const { return bst.size(); }
    bool empty() const { return bst.empty(); };
    void clear() { bst.clear(); };
    V access (K k);
    
    template <class T1, class T2>
    void setPair (custom::pair<T1, T2> p) {p = p.k, p.v;}; // without custom
    
    void insert(const custom::pair <K,V> &input);
    void insert (const K &k, const V &v);
    
    // nested classes
    class iterator;
        //custom::BST<V> bst;
        // iterator interfaces
        iterator  begin() { bst.begin(); }
        iterator  end();    //{ bst.end(); }
        iterator  find(const K & element);
private:
    V *data;
    custom::BST<custom::pair<K, V>> bst; // T will be a pair of k and v
      
};
/*******************************************
* MAP ITERATOR
********************************************/
template <class K, class V>
class map<K,V>::iterator
{
    friend class map<K,V>;
private:
    custom::BST<V> bst;
    K element;
public:
    iterator () {};
    iterator (custom::BST<V> iterator){};
    iterator (iterator &rhs){};
    iterator (const iterator & rhs) {*this = rhs;}
    iterator &operator= (const iterator &rhs)
    {
        //this->element = (custom::pair<K, V>)element;
        this->element = rhs.element; //need to convert element to pair
    }
};
/*******************************************
* MAP ITERATOR END
********************************************/
/********************************************
* FUNCTION:     FIND
* DESCRIPTION:  calls BST find()
* PARAMETER:    K &element
********************************************/
template <class K,class V>
typename map<K,V>::iterator map<K,V>::find (const K &element)
{
    return bst.find (element);
}

/********************************************
 * FUNCTION:     INSERT
 * DESCRIPTION:  Inserts an element in the 
 *               appropriate place in a map
 * PARAMETER:    receives a pair element
 ********************************************/
template <class K, class V>
void map<K,V>::insert(const custom::pair <K,V> &input)
{
   // need to setup iterators first
   iterator it = bst.find(input);

   if (it != nullptr)
   {
      *it = input;//
   }
   else
   {
      bst.insert(input);
   }

}

/********************************************
 * FUNCTION:     INSERT 2
 * DESCRIPTION:  Inserts an element in the 
 *               appropriate place in a map
 * PARAMETER:    receives a pair element
 ********************************************/
template <class K, class V>
void map<K,V>::insert (const K &k, const V &v)
{

   

}

/********************************************
 * FUNCTION:  Assignment Operator Overload
 * RETURNS:   ...
 * PARAMETER: ...
 ********************************************/
// return_type class_name::operator_name (args)
template <class K, class V>
V& map<K,V>::operator[] (const K &k) //this IS the access operator
{
    
}

template <class K, class V>
V map<K,V>::operator[] (const K &k) const
{
    
}
      /* // container-specific interfaces
      T & operator [] (int index)
      {
         return data[index];
      }
      const T & operator [] (int index) const 
      {
         return data[index];
      } */


#endif // MAP_H
